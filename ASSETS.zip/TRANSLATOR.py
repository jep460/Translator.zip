from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage

# File nav
OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"C:\Users\USER\Desktop\CODES\FINAL PROJECT CCO3\ASSETS")

# To use the file nav
def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)


# Tk design for GUI----------
window = Tk()

window.geometry("900x500")
window.configure(bg = "#4F4F4F")


canvas = Canvas(
    window,
    bg = "#4F4F4F",
    height = 500,
    width = 900,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge"
)

canvas.place(x = 0, y = 0)
entry_image_1 = PhotoImage(
    file=relative_to_assets("entry_1.png"))
entry_bg_1 = canvas.create_image(
    646.5,
    259.0,
    image=entry_image_1
)
entry_1 = Entry(
    bd=0,
    bg="#626262",
    fg="#000716",
    highlightthickness=0
)
entry_1.place(
    x=480.0,
    y=163.0,
    width=333.0,
    height=190.0
)

entry_image_2 = PhotoImage(
    file=relative_to_assets("entry_2.png"))
entry_bg_2 = canvas.create_image(
    252.5,
    259.0,
    image=entry_image_2
)
entry_2 = Entry(
    bd=0,
    bg="#626262",
    fg="#000716",
    highlightthickness=0
)
entry_2.place(
    x=86.0,
    y=163.0,
    width=333.0,
    height=190.0
)

button_image_1 = PhotoImage(
    file=relative_to_assets("button_1.png"))
button_1 = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=lambda: print("button_1 clicked"),
    relief="flat"
)
button_1.place(
    x=434.0,
    y=143.0,
    width=32.0,
    height=30.0
)

button_image_2 = PhotoImage(
    file=relative_to_assets("button_2.png"))
button_2 = Button(
    image=button_image_2,
    borderwidth=0,
    highlightthickness=0,
    command=lambda: print("button_2 clicked"),
    relief="flat"
)
button_2.place(
    x=335.0,
    y=128.0,
    width=99.0,
    height=19.0
)

button_image_3 = PhotoImage(
    file=relative_to_assets("button_3.png"))
button_3 = Button(
    image=button_image_3,
    borderwidth=0,
    highlightthickness=0,
    command=lambda: print("button_3 clicked"),
    relief="flat"
)
button_3.place(
    x=466.0,
    y=128.0,
    width=99.0,
    height=19.0
)

button_image_4 = PhotoImage(
    file=relative_to_assets("button_4.png"))
button_4 = Button(
    image=button_image_4,
    borderwidth=0,
    highlightthickness=0,
    command=lambda: print("button_4 clicked"),
    relief="flat"
)
button_4.place(
    x=668.0,
    y=123.0,
    width=160.0,
    height=29.0
)

button_image_5 = PhotoImage(
    file=relative_to_assets("button_5.png"))
button_5 = Button(
    image=button_image_5,
    borderwidth=0,
    highlightthickness=0,
    command=lambda: print("button_5 clicked"),
    relief="flat"
)
button_5.place(
    x=71.0,
    y=123.0,
    width=160.0,
    height=29.0
)

button_image_6 = PhotoImage(
    file=relative_to_assets("button_6.png"))
button_6 = Button(
    image=button_image_6,
    borderwidth=0,
    highlightthickness=0,
    command=lambda: print("button_6 clicked"),
    relief="flat"
)
button_6.place(
    x=798.0,
    y=324.0,
    width=22.0,
    height=21.0
)

button_image_7 = PhotoImage(
    file=relative_to_assets("button_7.png"))
button_7 = Button(
    image=button_image_7,
    borderwidth=0,
    highlightthickness=0,
    command=lambda: print("button_7 clicked"),
    relief="flat"
)
button_7.place(
    x=439.0,
    y=147.0,
    width=21.0,
    height=22.0
)
window.resizable(False, False)
window.mainloop()
